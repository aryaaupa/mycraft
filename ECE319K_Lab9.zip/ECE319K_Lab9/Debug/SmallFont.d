# FIXED

SmallFont.o: ../SmallFont.c \
 /Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/ECE319K_Lab9/SmallFont.h \
 ../../inc/ST7735.h
/Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/ECE319K_Lab9/SmallFont.h:
../../inc/ST7735.h:
