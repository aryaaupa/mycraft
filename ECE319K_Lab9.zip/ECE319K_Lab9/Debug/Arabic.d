# FIXED

Arabic.o: /Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/inc/Arabic.c \
 /Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/inc/Arabic.h \
 /Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/inc/ST7735.h
/Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/inc/Arabic.h:
/Users/aryaupadhyay/Downloads/MSPM0_ValvanoWare/inc/ST7735.h:
