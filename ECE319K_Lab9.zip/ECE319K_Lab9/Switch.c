/*
 * Switch.c
 *
 *  Created on: January 12, 2026
 *      Author: Arya Upadhyay
 */
#include <ti/devices/msp/msp.h>
#include "../inc/LaunchPad.h"
#include <stdint.h>
#include <ti/devices/msp/msp.h>
#include "../inc/LaunchPad.h"
#include "Switch.h"


// button assignments
// UP    = PB16
// DOWN  = PB19
// MINE  = PB12
// BUILD = PB17

#define UP_MASK     (1U << 16)
#define DOWN_MASK   (1U << 19)
#define MINE_MASK   (1U << 12)
#define BUILD_MASK  (1U << 17)

#define BUTTON_MASK (UP_MASK | DOWN_MASK | MINE_MASK | BUILD_MASK)

void Switch_Init(void){
    // LaunchPad_Init() already powers and resets GPIOB.
    // Do not reset GPIOB again.

    // Configure pins as GPIO inputs with pull-ups.
    // PINCM mode 1 = GPIO, INENA = input enabled,
    // PIPU = pull-up enabled.
    IOMUX->SECCFG.PINCM[PB16INDEX] = 0x00060081;
    IOMUX->SECCFG.PINCM[PB19INDEX] = 0x00060081;
    IOMUX->SECCFG.PINCM[PB12INDEX] = 0x00060081;
    IOMUX->SECCFG.PINCM[PB17INDEX] = 0x00060081;

    GPIOB->DOE31_0 &= ~BUTTON_MASK;
}

// Positive-logic result:
// 1 = UP, 2 = DOWN, 4 = MINE, 8 = BUILD
uint32_t Switch_In(void){
    uint32_t raw = GPIOB->DIN31_0;
    uint32_t result = 0;

    if((raw & UP_MASK) == 0){
        result |= 1;
    }
    if((raw & DOWN_MASK) == 0){
        result |= 2;
    }
    if((raw & MINE_MASK) == 0){
        result |= 4;
    }
    if((raw & BUILD_MASK) == 0){
        result |= 8;
    }

    return result;
}
